The KIM Clone has two EPROM sockets.  IC6 is the basic KIM monitor with a
few enhancements, while IC5 is the xKIM monitor.  The latest code for both of
these are always found on the Corsham Tech Githug repository:

IC6 KIM
https://github.com/CorshamTech/KIM-Monitor

IC5 xKIM
https://github.com/CorshamTech/xKIM

