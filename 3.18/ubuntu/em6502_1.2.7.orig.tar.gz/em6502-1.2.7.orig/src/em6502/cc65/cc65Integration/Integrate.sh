#!/bin/bash
# before running this script be sure you have git cloned the cc65 source to
# ~/6502/cc65
# this script only integrates the development env for cc65, no integration is needed
# for the cc65 executable environment.
# to install the executables :
# Latest from : http://download.opensuse.org/repositories/home:/strik/Debian_11/
# But try your own distribution first, it should be available in most cases
# This is configures for mint/ubuntu/deb distro
