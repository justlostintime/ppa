# gsh
Gambas Shell, an interactive shell and scripter that mixes Gambas code and Linux command lines.

### Current release 1.8.5
[Release page](https://github.com/justlostintime/gsh/releases/tag/v1.8.5): AppImage, Ubuntu and Debian packages and the
GambasShell-gsh-1.8 manual (pdf). Packages for Arch Linux, Fedora, Mageia, openSUSE and Slackware are in the
[PPA](https://github.com/justlostintime/ppa). The packages need Gambas 3.22 or later.

### Highlights of 1.8
- **AppImage that runs without Gambas installed**: it contains the Gambas runtime, the SharedMem and Scripter libraries,
  readline, less and dash. Tested on Ubuntu 22.04, 24.04 and 26.04, Debian 13, Fedora 44, Mageia 9, Arch Linux,
  openSUSE Leap 15.6 and Tumbleweed, and Slackware 15.0
- **Highlighting as you type**: Gambas code and command lines are coloured while they are typed, each `:;` part with its
  own highlighter. On by default, `$usehighlight = false` turns it off for a session
- **bash style parameters**: `$0`, `$1..$n`, `$#`, `$*`, `$@` work as in bash, `$!` is the process id of the last background job
- **Here documents** (`<<`) are supported
- **Background jobs** are compiled by gb.scripter and run directly, gbs3 is no longer used; `kill $!` also stops the
  command the job started, `jobs` records and shows every background job
- **Compiled scripts** start with `#!/usr/bin/env -S gsh -u --`
- **`&|`, `&|>` and `&|<`** pipe stdout and stderr together; a misplaced pipe, `&&` or `||` gives a clear error
- **Private variables**: `$path` is private to each gsh session and its children, `$pwd` to each process
- **Faster**: quicker variable access, shorter JIT compile times, robust locking in the shared memory library
- **Desktop integration**: `.gsh` files have their own MIME type, opening one from a file manager runs it in a terminal
- **Help** pages are converted to text by the new `htmltotext` sub, html2text is no longer needed
- **rpm packages** work on Fedora, Mageia and openSUSE
- **Version 1.8 manual**: help, man page, wiki and the pdf manual are up to date
- 1.8.5 package revision 3: the `donut` sub is faster, adapts to the terminal size and shifts colour

See [What's New](https://github.com/justlostintime/GambasShell/wiki/What's-New) for the details.

### Install from the PPA (Ubuntu/Debian)
```
sudo -i
curl -s --compressed "https://raw.githubusercontent.com/justlostintime/ppa/main/ubuntu/KEY.gpg" | gpg --dearmor > /etc/apt/trusted.gpg.d/westwood-archive-key.gpg
sudo curl -s --compressed -o /etc/apt/sources.list.d/gsh.list "https://raw.githubusercontent.com/justlostintime/ppa/main/ubuntu/gsh.list"
sudo apt update
sudo apt install gsh
```

### Try the AppImage
```
curl -LO https://github.com/justlostintime/gsh/releases/download/v1.8.5/gsh-1.8.5-x86_64.AppImage
chmod +x gsh-1.8.5-x86_64.AppImage
./gsh-1.8.5-x86_64.AppImage
```
If FUSE is not installed, run it with `APPIMAGE_EXTRACT_AND_RUN=1 ./gsh-1.8.5-x86_64.AppImage`.
Install a package to make gsh your login shell.

### Libraries
gb.scripter and sharedmem are built into gsh and do not need to be installed separately. The gsh package contains the
same library files as the separate westwood-* packages in the PPA: install gsh or the library packages, not both.

### Documentation
[Gambas Shell Documentation](https://github.com/justlostintime/GambasShell/wiki)

### What's New
[What's new with this release](https://github.com/justlostintime/GambasShell/wiki/What's-New)
