The source code for the xKIM monitor can be found on Github:

https://github.com/CorshamTech/xKIM


