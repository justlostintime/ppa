# Security Policy

## Supported Versions

6.1.2 

| Version | Supported          |
| ------- | ------------------ |
| 2.1.10  | :white_check_mark: |
| 1.x.x   | :x:                |

## Reporting a Vulnerability
Use the Issues page for both bugs and enhancement requests.
Use the templates available in this repository.
Bugs will be resoved with a few days. You may also email at the
email address of the owner.
