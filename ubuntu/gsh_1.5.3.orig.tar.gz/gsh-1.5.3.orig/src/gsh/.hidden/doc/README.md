# Documentation
This directory contains the different version
manuals for each release of GSH

# Internal help file
this contains the basic info displayed when
You type help in the terminal.