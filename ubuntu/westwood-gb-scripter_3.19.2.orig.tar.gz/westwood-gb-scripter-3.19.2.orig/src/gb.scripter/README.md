# gb.scripter
Gambas scripter as a component
