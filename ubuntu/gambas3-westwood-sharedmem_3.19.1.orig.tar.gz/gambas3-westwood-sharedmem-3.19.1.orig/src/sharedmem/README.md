# sharedmem

## Gambas3 Variable and object shared memory store
This can be used to store any valid gambas object or variable type
used named and un-named shared memory segments, 
can be used to communicate between local tasks in a machine.
